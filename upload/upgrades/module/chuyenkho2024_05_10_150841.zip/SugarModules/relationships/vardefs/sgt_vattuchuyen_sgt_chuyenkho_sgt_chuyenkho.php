<?php
// created: 2024-05-10 15:08:41
$dictionary["sgt_chuyenkho"]["fields"]["sgt_vattuchuyen_sgt_chuyenkho"] = array (
  'name' => 'sgt_vattuchuyen_sgt_chuyenkho',
  'type' => 'link',
  'relationship' => 'sgt_vattuchuyen_sgt_chuyenkho',
  'source' => 'non-db',
  'module' => 'sgt_vattuchuyen',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_SGT_VATTUCHUYEN_SGT_CHUYENKHO_FROM_SGT_VATTUCHUYEN_TITLE',
);
