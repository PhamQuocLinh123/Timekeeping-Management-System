# Tabbed Subpanels
### A tabbed subpanel solution for SuiteCRM / SugarCRM CE

Docs can be found at: https://blasher.github.io/tabbed_subpanels/
