<?php
$module_name = 'h_bangluong';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'NGAYTINHLUONG' => 
  array (
    'type' => 'date',
    'label' => 'LBL_NGAYTINHLUONG',
    'width' => '10%',
    'default' => true,
  ),
  'DUAN' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_DUAN',
    'id' => 'H_DUAN_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'TENNHANVIEN' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_TENNHANVIEN',
    'id' => 'H_NHANVIENDUAN_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
);
;
?>
