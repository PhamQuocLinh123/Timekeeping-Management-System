<?php
$dashletData['h_bangluongDashlet']['searchFields'] = array (
  'duan' => 
  array (
    'default' => '',
  ),
  'ngaytinhluong' => 
  array (
    'default' => '',
  ),
  'tennhanvien' => 
  array (
    'default' => '',
  ),
);
$dashletData['h_bangluongDashlet']['columns'] = array (
  'ngaytinhluong' => 
  array (
    'type' => 'date',
    'label' => 'LBL_NGAYTINHLUONG',
    'width' => '10%',
    'default' => true,
    'name' => 'ngaytinhluong',
  ),
  'duan' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_DUAN',
    'id' => 'H_DUAN_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
    'name' => 'duan',
  ),
  'tennhanvien' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_TENNHANVIEN',
    'id' => 'H_NHANVIENDUAN_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'date_modified' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_MODIFIED',
    'name' => 'date_modified',
    'default' => false,
  ),
  'created_by' => 
  array (
    'width' => '8%',
    'label' => 'LBL_CREATED',
    'name' => 'created_by',
    'default' => false,
  ),
  'date_entered' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_ENTERED',
    'default' => false,
    'name' => 'date_entered',
  ),
  'assigned_user_name' => 
  array (
    'width' => '8%',
    'label' => 'LBL_LIST_ASSIGNED_USER',
    'name' => 'assigned_user_name',
    'default' => false,
  ),
);
