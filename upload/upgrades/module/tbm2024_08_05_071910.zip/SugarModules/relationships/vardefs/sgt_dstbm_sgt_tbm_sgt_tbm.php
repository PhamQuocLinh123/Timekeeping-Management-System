<?php
// created: 2024-08-05 07:19:09
$dictionary["sgt_tbm"]["fields"]["sgt_dstbm_sgt_tbm"] = array (
  'name' => 'sgt_dstbm_sgt_tbm',
  'type' => 'link',
  'relationship' => 'sgt_dstbm_sgt_tbm',
  'source' => 'non-db',
  'module' => 'sgt_dstbm',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_SGT_DSTBM_SGT_TBM_FROM_SGT_DSTBM_TITLE',
);
