<?php
$module_name = 'h_duan';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'NGAYBATDAU' => 
  array (
    'type' => 'date',
    'label' => 'LBL_NGAYBATDAU',
    'width' => '10%',
    'default' => true,
  ),
  'NGAYDUKIENKETTHUC' => 
  array (
    'type' => 'date',
    'label' => 'LBL_NGAYDUKIENKETTHUC',
    'width' => '10%',
    'default' => true,
  ),
  'NGAYKETTHUC' => 
  array (
    'type' => 'date',
    'label' => 'LBL_NGAYKETTHUC',
    'width' => '10%',
    'default' => true,
  ),
  'TONGTIENNHANCONG' => 
  array (
    'type' => 'currency',
    'label' => 'LBL_TONGTIENNHANCONG',
    'currency_format' => true,
    'width' => '10%',
    'default' => true,
  ),
);
;
?>
