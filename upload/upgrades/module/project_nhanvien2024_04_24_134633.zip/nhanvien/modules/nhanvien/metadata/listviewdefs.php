<?php
$module_name = 'h_nhanvien';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'NGAYSINH' => 
  array (
    'type' => 'date',
    'label' => 'LBL_NGAYSINH',
    'width' => '10%',
    'default' => true,
  ),
  'SODIENTHOAI' => 
  array (
    'type' => 'phone',
    'label' => 'LBL_SODIENTHOAI',
    'width' => '10%',
    'default' => true,
  ),
  'MASOTHUE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_MASOTHUE',
    'width' => '10%',
    'default' => true,
  ),
  'BAOHIEM' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_BAOHIEM',
    'width' => '10%',
    'default' => true,
  ),
  'CCCD' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CCCD',
    'width' => '10%',
    'default' => true,
  ),
  'DIACHI' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_DIACHI',
    'width' => '10%',
    'default' => true,
  ),
  'CHUCVU' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CHUCVU',
    'width' => '10%',
    'default' => true,
  ),
  'PHONGBAN' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PHONGBAN',
    'width' => '10%',
    'default' => true,
  ),
  'BOPHAN' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_BOPHAN',
    'width' => '10%',
    'default' => true,
  ),
  'MUCLUONGTHOATHUAN' => 
  array (
    'type' => 'currency',
    'label' => 'LBL_MUCLUONGTHOATHUAN',
    'currency_format' => true,
    'width' => '10%',
    'default' => true,
  ),
  'NGANHANG' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_NGANHANG',
    'width' => '10%',
    'default' => true,
  ),
  'SOTAIKHOAN' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SOTAIKHOAN',
    'width' => '10%',
    'default' => true,
  ),
  'DIENTHOAIKHANCAP' => 
  array (
    'type' => 'phone',
    'label' => 'LBL_DIENTHOAIKHANCAP',
    'width' => '10%',
    'default' => true,
  ),
);
;
?>
