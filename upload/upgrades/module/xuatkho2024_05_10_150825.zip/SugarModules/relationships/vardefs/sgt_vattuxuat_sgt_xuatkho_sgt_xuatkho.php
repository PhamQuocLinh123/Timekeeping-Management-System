<?php
// created: 2024-05-10 15:08:25
$dictionary["sgt_xuatkho"]["fields"]["sgt_vattuxuat_sgt_xuatkho"] = array (
  'name' => 'sgt_vattuxuat_sgt_xuatkho',
  'type' => 'link',
  'relationship' => 'sgt_vattuxuat_sgt_xuatkho',
  'source' => 'non-db',
  'module' => 'sgt_vattuxuat',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_SGT_VATTUXUAT_SGT_XUATKHO_FROM_SGT_VATTUXUAT_TITLE',
);
