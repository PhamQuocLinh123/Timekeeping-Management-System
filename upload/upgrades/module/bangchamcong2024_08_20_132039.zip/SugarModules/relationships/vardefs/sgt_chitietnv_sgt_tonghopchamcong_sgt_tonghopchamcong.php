<?php
// created: 2024-08-20 13:20:39
$dictionary["sgt_tonghopchamcong"]["fields"]["sgt_chitietnv_sgt_tonghopchamcong"] = array (
  'name' => 'sgt_chitietnv_sgt_tonghopchamcong',
  'type' => 'link',
  'relationship' => 'sgt_chitietnv_sgt_tonghopchamcong',
  'source' => 'non-db',
  'module' => 'sgt_chitietnv',
  'bean_name' => 'sgt_chitietnv',
  'side' => 'right',
  'vname' => 'LBL_SGT_CHITIETNV_SGT_TONGHOPCHAMCONG_FROM_SGT_CHITIETNV_TITLE',
);
