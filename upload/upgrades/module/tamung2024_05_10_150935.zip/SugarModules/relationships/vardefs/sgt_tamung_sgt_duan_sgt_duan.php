<?php
// created: 2024-05-10 15:09:34
$dictionary["sgt_duan"]["fields"]["sgt_tamung_sgt_duan"] = array (
  'name' => 'sgt_tamung_sgt_duan',
  'type' => 'link',
  'relationship' => 'sgt_tamung_sgt_duan',
  'source' => 'non-db',
  'module' => 'sgt_tamung',
  'bean_name' => 'sgt_tamung',
  'side' => 'right',
  'vname' => 'LBL_SGT_TAMUNG_SGT_DUAN_FROM_SGT_TAMUNG_TITLE',
);
