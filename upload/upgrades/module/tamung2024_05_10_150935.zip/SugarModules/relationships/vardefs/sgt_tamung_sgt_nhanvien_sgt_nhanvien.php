<?php
// created: 2024-05-10 15:09:34
$dictionary["sgt_nhanvien"]["fields"]["sgt_tamung_sgt_nhanvien"] = array (
  'name' => 'sgt_tamung_sgt_nhanvien',
  'type' => 'link',
  'relationship' => 'sgt_tamung_sgt_nhanvien',
  'source' => 'non-db',
  'module' => 'sgt_tamung',
  'bean_name' => 'sgt_tamung',
  'side' => 'right',
  'vname' => 'LBL_SGT_TAMUNG_SGT_NHANVIEN_FROM_SGT_TAMUNG_TITLE',
);
