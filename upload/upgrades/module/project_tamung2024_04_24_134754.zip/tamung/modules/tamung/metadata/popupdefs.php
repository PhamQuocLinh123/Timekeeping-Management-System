<?php
$popupMeta = array (
    'moduleMain' => 'h_tamung',
    'varName' => 'h_tamung',
    'orderBy' => 'h_tamung.name',
    'whereClauses' => array (
  'tennhanvien' => 'h_tamung.tennhanvien',
),
    'searchInputs' => array (
  4 => 'tennhanvien',
),
    'searchdefs' => array (
  'tennhanvien' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_TENNHANVIEN',
    'id' => 'H_NHANVIEN_ID_C',
    'link' => true,
    'width' => '10%',
    'name' => 'tennhanvien',
  ),
),
);
