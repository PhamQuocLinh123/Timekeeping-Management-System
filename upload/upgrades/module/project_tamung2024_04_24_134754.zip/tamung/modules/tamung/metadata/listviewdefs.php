<?php
$module_name = 'h_tamung';
$listViewDefs [$module_name] = 
array (
  'TENNHANVIEN' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_TENNHANVIEN',
    'id' => 'H_NHANVIEN_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'NGAYTAMUNG' => 
  array (
    'type' => 'date',
    'label' => 'LBL_NGAYTAMUNG',
    'width' => '10%',
    'default' => true,
  ),
  'CREATED_BY_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_CREATED',
    'id' => 'CREATED_BY',
    'width' => '10%',
    'default' => true,
  ),
  'NGUOICHITIEN' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_NGUOICHITIEN',
    'id' => 'H_NHANVIEN_ID2_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'SOTIENTAMUNG' => 
  array (
    'type' => 'currency',
    'label' => 'LBL_SOTIENTAMUNG',
    'currency_format' => true,
    'width' => '10%',
    'default' => true,
  ),
  'DUAN' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_DUAN',
    'id' => 'H_DUAN_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'NGUOIDUYETTAMUNG' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_NGUOIDUYETTAMUNG',
    'id' => 'H_NHANVIEN_ID1_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'TINHTRANGTAMUNG' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_TINHTRANGTAMUNG',
    'width' => '10%',
    'default' => true,
  ),
);
;
?>
