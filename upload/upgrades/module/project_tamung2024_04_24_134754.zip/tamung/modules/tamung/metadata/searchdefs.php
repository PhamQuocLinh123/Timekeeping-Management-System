<?php
$module_name = 'h_tamung';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'tennhanvien' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_TENNHANVIEN',
        'id' => 'H_NHANVIEN_ID_C',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'tennhanvien',
      ),
      'duan' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_DUAN',
        'id' => 'H_DUAN_ID_C',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'duan',
      ),
    ),
    'advanced_search' => 
    array (
      'tennhanvien' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_TENNHANVIEN',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'id' => 'H_NHANVIEN_ID_C',
        'name' => 'tennhanvien',
      ),
      'duan' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_DUAN',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'id' => 'H_DUAN_ID_C',
        'name' => 'duan',
      ),
      'nguoiduyettamung' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_NGUOIDUYETTAMUNG',
        'id' => 'H_NHANVIEN_ID1_C',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'nguoiduyettamung',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
;
?>
