<?php
// created: 2024-05-02 14:19:23
$dictionary["sgt_doi"]["fields"]["sgt_nhanvien_sgt_doi"] = array (
  'name' => 'sgt_nhanvien_sgt_doi',
  'type' => 'link',
  'relationship' => 'sgt_nhanvien_sgt_doi',
  'source' => 'non-db',
  'module' => 'sgt_nhanvien',
  'bean_name' => 'sgt_nhanvien',
  'side' => 'right',
  'vname' => 'LBL_SGT_NHANVIEN_SGT_DOI_FROM_SGT_NHANVIEN_TITLE',
);
