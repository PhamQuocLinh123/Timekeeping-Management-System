<?php
// created: 2024-04-27 10:06:48
$dictionary["sgt_nhanvien"]["fields"]["sgt_nhanvien_sgt_chamcong"] = array (
  'name' => 'sgt_nhanvien_sgt_chamcong',
  'type' => 'link',
  'relationship' => 'sgt_nhanvien_sgt_chamcong',
  'source' => 'non-db',
  'module' => 'sgt_chamcong',
  'bean_name' => 'sgt_chamcong',
  'side' => 'right',
  'vname' => 'LBL_SGT_NHANVIEN_SGT_CHAMCONG_FROM_SGT_CHAMCONG_TITLE',
);
