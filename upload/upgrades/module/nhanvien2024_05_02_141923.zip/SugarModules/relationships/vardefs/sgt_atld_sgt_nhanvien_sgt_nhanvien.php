<?php
// created: 2024-05-02 14:19:23
$dictionary["sgt_nhanvien"]["fields"]["sgt_atld_sgt_nhanvien"] = array (
  'name' => 'sgt_atld_sgt_nhanvien',
  'type' => 'link',
  'relationship' => 'sgt_atld_sgt_nhanvien',
  'source' => 'non-db',
  'module' => 'sgt_atld',
  'bean_name' => 'sgt_atld',
  'side' => 'right',
  'vname' => 'LBL_SGT_ATLD_SGT_NHANVIEN_FROM_SGT_ATLD_TITLE',
);
