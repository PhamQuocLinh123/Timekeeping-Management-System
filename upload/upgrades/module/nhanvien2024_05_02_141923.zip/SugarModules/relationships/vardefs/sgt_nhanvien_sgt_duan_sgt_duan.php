<?php
// created: 2024-05-02 14:19:23
$dictionary["sgt_duan"]["fields"]["sgt_nhanvien_sgt_duan"] = array (
  'name' => 'sgt_nhanvien_sgt_duan',
  'type' => 'link',
  'relationship' => 'sgt_nhanvien_sgt_duan',
  'source' => 'non-db',
  'module' => 'sgt_nhanvien',
  'bean_name' => 'sgt_nhanvien',
  'vname' => 'LBL_SGT_NHANVIEN_SGT_DUAN_FROM_SGT_NHANVIEN_TITLE',
);
