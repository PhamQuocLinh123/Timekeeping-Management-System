<?php
$dashletData['h_nhanvienDashlet']['searchFields'] = array (
  'name' => 
  array (
    'default' => '',
  ),
  'ngaysinh' => 
  array (
    'default' => '',
  ),
  'cccd' => 
  array (
    'default' => '',
  ),
);
$dashletData['h_nhanvienDashlet']['columns'] = array (
  'name' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
    'name' => 'name',
  ),
  'ngaysinh' => 
  array (
    'type' => 'date',
    'label' => 'LBL_NGAYSINH',
    'width' => '10%',
    'default' => true,
    'name' => 'ngaysinh',
  ),
  'cccd' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CCCD',
    'width' => '10%',
    'default' => true,
    'name' => 'cccd',
  ),
  'sodienthoai' => 
  array (
    'type' => 'phone',
    'label' => 'LBL_SODIENTHOAI',
    'width' => '10%',
    'default' => true,
    'name' => 'sodienthoai',
  ),
  'baohiem' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_BAOHIEM',
    'width' => '10%',
    'default' => true,
    'name' => 'baohiem',
  ),
  'masothue' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_MASOTHUE',
    'width' => '10%',
    'default' => true,
    'name' => 'masothue',
  ),
);
