<?php
$module_name = 'sgt_nhanvien';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'SODIENTHOAI' => 
  array (
    'type' => 'phone',
    'label' => 'LBL_SODIENTHOAI',
    'width' => '10%',
    'default' => true,
  ),
  'MA_NV' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_MA_NV',
    'width' => '10%',
    'default' => true,
  ),
  'CCCD' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CCCD',
    'width' => '10%',
    'default' => true,
  ),
  'CHUCVU' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CHUCVU',
    'width' => '10%',
    'default' => true,
  ),
  'NGANHANG' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_NGANHANG',
    'width' => '10%',
    'default' => true,
  ),
  'SOTAIKHOAN' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SOTAIKHOAN',
    'width' => '10%',
    'default' => true,
  ),
  'DIENTHOAIKHANCAP' => 
  array (
    'type' => 'phone',
    'label' => 'LBL_DIENTHOAIKHANCAP',
    'width' => '10%',
    'default' => true,
  ),
);
;
?>
