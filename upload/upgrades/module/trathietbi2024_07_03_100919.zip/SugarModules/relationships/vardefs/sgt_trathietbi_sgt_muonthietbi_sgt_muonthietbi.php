<?php
// created: 2024-07-03 10:09:18
$dictionary["sgt_muonthietbi"]["fields"]["sgt_trathietbi_sgt_muonthietbi"] = array (
  'name' => 'sgt_trathietbi_sgt_muonthietbi',
  'type' => 'link',
  'relationship' => 'sgt_trathietbi_sgt_muonthietbi',
  'source' => 'non-db',
  'module' => 'sgt_trathietbi',
  'bean_name' => 'sgt_trathietbi',
  'side' => 'right',
  'vname' => 'LBL_SGT_TRATHIETBI_SGT_MUONTHIETBI_FROM_SGT_TRATHIETBI_TITLE',
);
