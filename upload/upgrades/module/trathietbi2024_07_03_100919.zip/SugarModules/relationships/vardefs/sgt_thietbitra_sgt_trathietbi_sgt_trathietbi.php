<?php
// created: 2024-07-03 10:09:18
$dictionary["sgt_trathietbi"]["fields"]["sgt_thietbitra_sgt_trathietbi"] = array (
  'name' => 'sgt_thietbitra_sgt_trathietbi',
  'type' => 'link',
  'relationship' => 'sgt_thietbitra_sgt_trathietbi',
  'source' => 'non-db',
  'module' => 'sgt_thietbitra',
  'bean_name' => 'sgt_thietbitra',
  'side' => 'right',
  'vname' => 'LBL_SGT_THIETBITRA_SGT_TRATHIETBI_FROM_SGT_THIETBITRA_TITLE',
);
