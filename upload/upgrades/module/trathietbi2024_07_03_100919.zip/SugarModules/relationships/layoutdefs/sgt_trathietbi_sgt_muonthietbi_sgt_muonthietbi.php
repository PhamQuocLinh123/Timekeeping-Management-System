<?php
 // created: 2024-07-03 10:09:17
$layout_defs["sgt_muonthietbi"]["subpanel_setup"]['sgt_trathietbi_sgt_muonthietbi'] = array (
  'order' => 100,
  'module' => 'sgt_trathietbi',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SGT_TRATHIETBI_SGT_MUONTHIETBI_FROM_SGT_TRATHIETBI_TITLE',
  'get_subpanel_data' => 'sgt_trathietbi_sgt_muonthietbi',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
