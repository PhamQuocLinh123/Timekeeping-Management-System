<?php
 // created: 2024-07-03 10:09:18
$layout_defs["sgt_trathietbi"]["subpanel_setup"]['sgt_thietbitra_sgt_trathietbi'] = array (
  'order' => 100,
  'module' => 'sgt_thietbitra',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SGT_THIETBITRA_SGT_TRATHIETBI_FROM_SGT_THIETBITRA_TITLE',
  'get_subpanel_data' => 'sgt_thietbitra_sgt_trathietbi',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
