<?php
$popupMeta = array (
    'moduleMain' => 'sgt_thietbitra',
    'varName' => 'sgt_thietbitra',
    'orderBy' => 'sgt_thietbitra.name',
    'whereClauses' => array (
  'name' => 'sgt_thietbitra.name',
  'ma_vt' => 'sgt_thietbitra.ma_vt',
),
    'searchInputs' => array (
  1 => 'name',
  4 => 'ma_vt',
),
    'searchdefs' => array (
  'name' => 
  array (
    'name' => 'name',
    'width' => '10%',
  ),
  'ma_vt' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_MA_VT',
    'width' => '10%',
    'name' => 'ma_vt',
  ),
),
);
