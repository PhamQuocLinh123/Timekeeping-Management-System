<?php
// created: 2024-05-10 15:08:56
$dictionary["sgt_muonthietbi"]["fields"]["sgt_thietbimuon_sgt_muonthietbi"] = array (
  'name' => 'sgt_thietbimuon_sgt_muonthietbi',
  'type' => 'link',
  'relationship' => 'sgt_thietbimuon_sgt_muonthietbi',
  'source' => 'non-db',
  'module' => 'sgt_thietbimuon',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_SGT_THIETBIMUON_SGT_MUONTHIETBI_FROM_SGT_THIETBIMUON_TITLE',
);
