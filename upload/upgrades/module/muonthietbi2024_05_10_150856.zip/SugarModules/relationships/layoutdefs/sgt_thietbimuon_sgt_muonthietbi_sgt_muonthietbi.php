<?php
 // created: 2024-05-10 15:08:55
$layout_defs["sgt_muonthietbi"]["subpanel_setup"]['sgt_thietbimuon_sgt_muonthietbi'] = array (
  'order' => 100,
  'module' => 'sgt_thietbimuon',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SGT_THIETBIMUON_SGT_MUONTHIETBI_FROM_SGT_THIETBIMUON_TITLE',
  'get_subpanel_data' => 'sgt_thietbimuon_sgt_muonthietbi',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
