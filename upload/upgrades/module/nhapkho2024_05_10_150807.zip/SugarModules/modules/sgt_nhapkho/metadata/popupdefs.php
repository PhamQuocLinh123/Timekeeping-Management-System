<?php
$popupMeta = array (
    'moduleMain' => 'sgt_nhapkho',
    'varName' => 'sgt_nhapkho',
    'orderBy' => 'sgt_nhapkho.name',
    'whereClauses' => array (
  'name' => 'sgt_nhapkho.name',
  'ngaynhap' => 'sgt_nhapkho.ngaynhap',
  'tinhtrang' => 'sgt_nhapkho.tinhtrang',
),
    'searchInputs' => array (
  1 => 'name',
  4 => 'ngaynhap',
  5 => 'tinhtrang',
),
    'searchdefs' => array (
  'name' => 
  array (
    'name' => 'name',
    'width' => '10%',
  ),
  'ngaynhap' => 
  array (
    'type' => 'date',
    'label' => 'LBL_NGAYNHAP',
    'width' => '10%',
    'name' => 'ngaynhap',
  ),
  'tinhtrang' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_TINHTRANG',
    'width' => '10%',
    'name' => 'tinhtrang',
  ),
),
);
