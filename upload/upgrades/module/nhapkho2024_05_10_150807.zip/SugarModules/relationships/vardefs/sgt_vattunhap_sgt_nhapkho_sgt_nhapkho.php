<?php
// created: 2024-05-10 15:08:07
$dictionary["sgt_nhapkho"]["fields"]["sgt_vattunhap_sgt_nhapkho"] = array (
  'name' => 'sgt_vattunhap_sgt_nhapkho',
  'type' => 'link',
  'relationship' => 'sgt_vattunhap_sgt_nhapkho',
  'source' => 'non-db',
  'module' => 'sgt_vattunhap',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_SGT_VATTUNHAP_SGT_NHAPKHO_FROM_SGT_VATTUNHAP_TITLE',
);
