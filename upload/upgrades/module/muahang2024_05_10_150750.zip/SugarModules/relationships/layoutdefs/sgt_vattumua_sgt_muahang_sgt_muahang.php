<?php
 // created: 2024-05-10 15:07:50
$layout_defs["sgt_muahang"]["subpanel_setup"]['sgt_vattumua_sgt_muahang'] = array (
  'order' => 100,
  'module' => 'sgt_vattumua',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SGT_VATTUMUA_SGT_MUAHANG_FROM_SGT_VATTUMUA_TITLE',
  'get_subpanel_data' => 'sgt_vattumua_sgt_muahang',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
