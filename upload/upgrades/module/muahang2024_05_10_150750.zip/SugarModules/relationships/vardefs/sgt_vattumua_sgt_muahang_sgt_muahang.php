<?php
// created: 2024-05-10 15:07:50
$dictionary["sgt_muahang"]["fields"]["sgt_vattumua_sgt_muahang"] = array (
  'name' => 'sgt_vattumua_sgt_muahang',
  'type' => 'link',
  'relationship' => 'sgt_vattumua_sgt_muahang',
  'source' => 'non-db',
  'module' => 'sgt_vattumua',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_SGT_VATTUMUA_SGT_MUAHANG_FROM_SGT_VATTUMUA_TITLE',
);
