<?php
// created: 2024-05-02 14:18:49
$dictionary["sgt_duan"]["fields"]["sgt_chamcong_sgt_duan"] = array (
  'name' => 'sgt_chamcong_sgt_duan',
  'type' => 'link',
  'relationship' => 'sgt_chamcong_sgt_duan',
  'source' => 'non-db',
  'module' => 'sgt_chamcong',
  'bean_name' => 'sgt_chamcong',
  'side' => 'right',
  'vname' => 'LBL_SGT_CHAMCONG_SGT_DUAN_FROM_SGT_CHAMCONG_TITLE',
);
