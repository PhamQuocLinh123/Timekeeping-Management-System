<?php
// created: 2024-05-02 14:18:48
$dictionary["sgt_chamcong"]["fields"]["sgt_dschamcong_sgt_chamcong"] = array (
  'name' => 'sgt_dschamcong_sgt_chamcong',
  'type' => 'link',
  'relationship' => 'sgt_dschamcong_sgt_chamcong',
  'source' => 'non-db',
  'module' => 'sgt_dschamcong',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_SGT_DSCHAMCONG_SGT_CHAMCONG_FROM_SGT_DSCHAMCONG_TITLE',
);
