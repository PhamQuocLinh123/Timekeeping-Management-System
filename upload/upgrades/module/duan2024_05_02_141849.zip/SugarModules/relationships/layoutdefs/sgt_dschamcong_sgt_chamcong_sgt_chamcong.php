<?php
 // created: 2024-05-02 14:18:48
$layout_defs["sgt_chamcong"]["subpanel_setup"]['sgt_dschamcong_sgt_chamcong'] = array (
  'order' => 100,
  'module' => 'sgt_dschamcong',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SGT_DSCHAMCONG_SGT_CHAMCONG_FROM_SGT_DSCHAMCONG_TITLE',
  'get_subpanel_data' => 'sgt_dschamcong_sgt_chamcong',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
