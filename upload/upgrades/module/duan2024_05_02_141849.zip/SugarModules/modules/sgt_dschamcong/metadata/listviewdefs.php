<?php
$module_name = 'sgt_dschamcong';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'MA_NV' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_MA_NV',
    'width' => '10%',
    'default' => true,
  ),
  'NGAYCHAMCONG' => 
  array (
    'type' => 'date',
    'label' => 'LBL_NGAYCHAMCONG',
    'width' => '10%',
    'default' => true,
  ),
  'TONGGIOSANG' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_TONGGIOSANG',
    'width' => '10%',
    'default' => true,
  ),
  'TONGGIOCHIEU' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_TONGGIOCHIEU',
    'width' => '10%',
    'default' => true,
  ),
  'TONGGIOLAM' => 
  array (
    'type' => 'float',
    'label' => 'LBL_TONGGIOLAM',
    'width' => '10%',
    'default' => true,
  ),
  'DACBIET' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_DACBIET',
    'width' => '10%',
    'default' => true,
  ),
  'DUAN' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_DUAN',
    'id' => 'SGT_DUAN_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
);
;
?>
