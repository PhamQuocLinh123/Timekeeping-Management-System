<?php
$dashletData['h_danhsachnhanluongDashlet']['searchFields'] = array (
  'tennhanvien' => 
  array (
    'default' => '',
  ),
);
$dashletData['h_danhsachnhanluongDashlet']['columns'] = array (
  'tennhanvien' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_TENNHANVIEN',
    'id' => 'H_NHANVIEN_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'ngaycongquydoi' => 
  array (
    'type' => 'float',
    'label' => 'LBL_NGAYCONGQUYDOI',
    'width' => '10%',
    'default' => true,
  ),
  'tongtienluong' => 
  array (
    'type' => 'currency',
    'label' => 'LBL_TONGTIENLUONG',
    'currency_format' => true,
    'width' => '10%',
    'default' => true,
  ),
  'date_modified' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_MODIFIED',
    'name' => 'date_modified',
    'default' => false,
  ),
  'tonggiotangca' => 
  array (
    'type' => 'float',
    'label' => 'LBL_TONGGIOTANGCA',
    'width' => '10%',
    'default' => false,
  ),
  'tonggiohanhchinh' => 
  array (
    'type' => 'float',
    'label' => 'LBL_TONGGIOHANHCHINH',
    'width' => '10%',
    'default' => false,
  ),
  'tonggiongayle' => 
  array (
    'type' => 'float',
    'label' => 'LBL_TONGGIONGAYLE',
    'width' => '10%',
    'default' => false,
  ),
  'name' => 
  array (
    'width' => '40%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'default' => false,
    'name' => 'name',
  ),
  'date_entered' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_ENTERED',
    'default' => false,
    'name' => 'date_entered',
  ),
  'created_by' => 
  array (
    'width' => '8%',
    'label' => 'LBL_CREATED',
    'name' => 'created_by',
    'default' => false,
  ),
  'assigned_user_name' => 
  array (
    'width' => '8%',
    'label' => 'LBL_LIST_ASSIGNED_USER',
    'name' => 'assigned_user_name',
    'default' => false,
  ),
);
