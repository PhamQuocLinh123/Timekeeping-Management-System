<?php
// created: 2024-05-02 14:19:37
$dictionary["sgt_bangluong"]["fields"]["sgt_dsluong_sgt_bangluong"] = array (
  'name' => 'sgt_dsluong_sgt_bangluong',
  'type' => 'link',
  'relationship' => 'sgt_dsluong_sgt_bangluong',
  'source' => 'non-db',
  'module' => 'sgt_dsluong',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_SGT_DSLUONG_SGT_BANGLUONG_FROM_SGT_DSLUONG_TITLE',
);
