<?php
// created: 2024-05-02 14:19:37
$dictionary["sgt_nhanvien"]["fields"]["sgt_dsluong_sgt_nhanvien"] = array (
  'name' => 'sgt_dsluong_sgt_nhanvien',
  'type' => 'link',
  'relationship' => 'sgt_dsluong_sgt_nhanvien',
  'source' => 'non-db',
  'module' => 'sgt_dsluong',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_SGT_DSLUONG_SGT_NHANVIEN_FROM_SGT_DSLUONG_TITLE',
);
