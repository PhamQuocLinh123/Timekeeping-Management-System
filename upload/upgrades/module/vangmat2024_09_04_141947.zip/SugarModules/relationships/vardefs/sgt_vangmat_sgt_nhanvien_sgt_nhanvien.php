<?php
// created: 2024-09-03 21:32:58
$dictionary["sgt_nhanvien"]["fields"]["sgt_vangmat_sgt_nhanvien"] = array (
  'name' => 'sgt_vangmat_sgt_nhanvien',
  'type' => 'link',
  'relationship' => 'sgt_vangmat_sgt_nhanvien',
  'source' => 'non-db',
  'module' => 'sgt_vangmat',
  'bean_name' => 'sgt_vangmat',
  'side' => 'right',
  'vname' => 'LBL_SGT_VANGMAT_SGT_NHANVIEN_FROM_SGT_VANGMAT_TITLE',
);
