<?php
$module_name = 'sgt_vangmat';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'MA_NV' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_MA_NV',
    'width' => '10%',
    'default' => true,
  ),
  'TUNGAY' => 
  array (
    'type' => 'date',
    'label' => 'LBL_TUNGAY',
    'width' => '10%',
    'default' => true,
  ),
  'DENNGAY' => 
  array (
    'type' => 'date',
    'label' => 'LBL_DENNGAY',
    'width' => '10%',
    'default' => true,
  ),
  'PHEDUYET' => 
  array (
    'type' => 'bool',
    'default' => true,
    'label' => 'LBL_PHEDUYET',
    'width' => '10%',
  ),
);
;
?>
