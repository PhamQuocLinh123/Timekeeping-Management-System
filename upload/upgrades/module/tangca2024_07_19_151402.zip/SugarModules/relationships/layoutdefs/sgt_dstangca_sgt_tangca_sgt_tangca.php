<?php
 // created: 2024-07-19 15:14:02
$layout_defs["sgt_tangca"]["subpanel_setup"]['sgt_dstangca_sgt_tangca'] = array (
  'order' => 100,
  'module' => 'sgt_dstangca',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SGT_DSTANGCA_SGT_TANGCA_FROM_SGT_DSTANGCA_TITLE',
  'get_subpanel_data' => 'sgt_dstangca_sgt_tangca',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
