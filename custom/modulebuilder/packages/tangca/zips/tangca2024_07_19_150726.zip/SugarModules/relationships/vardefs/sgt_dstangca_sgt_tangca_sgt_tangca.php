<?php
// created: 2024-07-19 15:07:25
$dictionary["sgt_tangca"]["fields"]["sgt_dstangca_sgt_tangca"] = array (
  'name' => 'sgt_dstangca_sgt_tangca',
  'type' => 'link',
  'relationship' => 'sgt_dstangca_sgt_tangca',
  'source' => 'non-db',
  'module' => 'sgt_dstangca',
  'bean_name' => 'sgt_dstangca',
  'side' => 'right',
  'vname' => 'LBL_SGT_DSTANGCA_SGT_TANGCA_FROM_SGT_DSTANGCA_TITLE',
);
